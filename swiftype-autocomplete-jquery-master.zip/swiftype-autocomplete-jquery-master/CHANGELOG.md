## Version 1.1 (December 3, 2012) ##

* Make disableAutocomplete option configurable as a function.

* Make dropdown style configurable as a function.

* Change the dropdown element layout and CSS to match the Swiftype embed. 
  **NOTE:** This is a breaking change if you have CSS rules targetting the old layout.
 
## Version 1.0 (October 19, 2012) ##

* Arbitrary starting point.

